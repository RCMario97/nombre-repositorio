from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

#Logos a utilizar [ ] \

usuario_admin = [["Administrador", "admin"]]
usuario_clientes = [ ]
admin=0

#Bienvenida al usuario
print ("¡BIENVENIDO NUEVAMENTE!")
print ("    Mi nombre es GERENBOT y sere tu asistente virtual...")
print ("    Estare disponible para ti las 24 horas del dia, los 7 dias de la semana.")
print ("    Antes de continuar... Iniciemos sesion en la plataforma.")
print ("")

usuario = input("USUARIO: ")
contra = input("CONTRASEÑA: ")

#Bienvenida al usuario administrador
for user in usuario_admin:
  if user[0] == usuario and user[1] == contra:
   print(" ")
   print("  *** GERENBOT INFORMA QUE USTED ACABA DE INICIAR SESIÓN COMO ADMINISTRADOR: *** ")
   admin=1
   
#Error al no ser administrador
  else:
   print("")
   print ("    Lo sentimos, pero GERENBOT por el momento solamente esta disponible para Administradores. ") 
   break

  if admin == 1:
    menu=0
    while not menu:

#Imprime lo que dira al programa si el usuario es admin
      print ("    \n¿Que puedo hacer por usted?")
      print ("\nSelecciona una opción: \n \n 1.- (A) Mostrar los 50 PRODUCTOS MAS VENDIDOS y los 100 PRODUCTOS MAS BUSCADOS \n 2.- (B) Mostrar los 50 PRODUCTOS MENOS VENDIDOS y los 100 PRODUCTOS CON MENORES BUSQUEDAS \n 3.- (C) Mostrar los 20 PRODUCTOS CON MEJORES RESEÑAS y los 20 PRODUCTOS CON PEORES RESEÑAS \n 4.- (D) Mostrar el TOTAL DE INGRESOS \n 5.- (S) SALIR DEL MENU\n")

      opcion_seleccionada = input ("ELIGE LA OPCION DESEADA (A / B / C / D / S) : ")
      opcion_correcta=0

#Opcion numero 1: Elementos mas vendidos y buscados
      while opcion_correcta != 1:
        if opcion_seleccionada == "A":
          print("Muy bien, Haz seleccionado la opcion de: Mostrar los 50 PRODUCTOS MAS VENDIDOS y los 100 PRODUCTOS MAS BUSCADOS ")
          opcion_correcta=1
          print("")
          print("Los 50 Productos mas vendidos son los siguientes: ")

          contador=0
          total_ventas = [ ]

#empezamos con el FOR que nos ayudara a organizar nuestra lista, y empezaremos a llenar otra lista en blanco donde iremos ordenando los productos de mayor a menor
          for producto in lifestore_products:
            for venta in lifestore_sales:
              if producto[0]==venta[1]:
                contador += 1
            formato_correcto = [producto[0], producto[1], contador]
            total_ventas.append(formato_correcto)
            contador=0

          longitud=len(total_ventas)
          for elemento in range (0,longitud):
            for elemento2 in range (0,longitud-elemento-1):
              if (total_ventas[elemento2][2] < total_ventas[elemento2+1][2]):
                total_ventas[elemento2], total_ventas[elemento2+1] = total_ventas [elemento2+1], total_ventas[elemento2]                       
          for total in total_ventas:
            print ("\n\n\n-EL PRODUCTO CON EL ID:\n ",total[0], "\n\n-CON EL NOMBRE DE:\n  ",total[1], "\n\n-FUE VENDIDO\n", total[2], "veces \n")

#Es el mismo proceso que el bloque de codigo anterior, solamente que aqui es para los productos mas buscados
          print("Estos son los 100 productos mas buscados:")
          contador1=0
          total_buscados = []

          for producto in lifestore_products:
            for busqueda in lifestore_searches:
              if producto[0]==busqueda[1]:
                contador1 += 1
            formato_correcto1=[producto[0], producto[1], contador1]
            total_buscados.append(formato_correcto1)
            contador1=0
         
          longitud=len(total_buscados)
          for elemento in range (0,longitud):
            for elemento2 in range (0,longitud-elemento-1):
              if (total_buscados[elemento2][2] < total_buscados[elemento2+1][2]):
                total_buscados[elemento2], total_buscados[elemento2+1] = total_buscados [elemento2+1], total_buscados[elemento2]                       
          for total in total_buscados:
            print ("\n\n\n-EL PRODUCTO CON EL ID:\n ",total[0], "\n\n-CON EL NOMBRE DE:\n  ",total[1], "\n\n-FUE BUSCADOS\n", total[2], "veces \n")


 #demas opciones a elegir por el usuario           
        elif opcion_seleccionada == "B":
          print("Muy bien, Haz seleccionado la opcion de: Mostrar los 50 PRODUCTOS MENOS VENDIDOS y los 100 PRODUCTOS CON MENORES BUSQUEDAS ")
          print("\n*****LO SENTIMOS, SE HA PRESENTADO UN ERROR EN ESTA FUNCION, FAVOR DE CONTACTARSE CON EL DEPARTAMENTO DE SISTEMAS PARA REPORTAR EL PROBLEMA***** ")
          opcion_correcta=1
        elif opcion_seleccionada == "C":
          print ("Muy bien, Haz seleccionado la opcion de: Mostrar los 20 PRODUCTOS CON MEJORES RESEÑAS y los 20 PRODUCTOS CON PEORES RESEÑAS ")
          print("\n*****LO SENTIMOS, SE HA PRESENTADO UN ERROR EN ESTA FUNCION, FAVOR DE CONTACTARSE CON EL DEPARTAMENTO DE SISTEMAS PARA REPORTAR EL PROBLEMA***** ")
          opcion_correcta=1
        elif opcion_seleccionada == "D":
          print ("Muy bien, Haz seleccionado la opcion de: Mostrar el TOTAL DE INGRESOS ")
          print("\n*****LO SENTIMOS, SE HA PRESENTADO UN ERROR EN ESTA FUNCION, FAVOR DE CONTACTARSE CON EL DEPARTAMENTO DE SISTEMAS PARA REPORTAR EL PROBLEMA***** ")
          opcion_correcta=1
        elif opcion_seleccionada == "S":
          print("****GRACIAS POR SU CONSULTA, ESTA SESIÓN HA TERMINADO****")
          menu=1
          break
        else:
          print ("Disculpe, no encontramos la opcion solicitada, intente de nuevo.\n")
          opcion_seleccionada = input ("ELIGE LA OPCION DESEADA (A / B / C / D / S) : ")



